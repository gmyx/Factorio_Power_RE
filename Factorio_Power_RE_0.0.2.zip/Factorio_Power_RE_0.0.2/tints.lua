tints={
	mk1 = {
		tint = {r=000/255, g=255/255, b=255/255} -- light blue
	},
	mk2 = {
		tint = {r=128/255, g=255/255, b=128/255} -- light green
	},
	mk3 = {
		tint = {r=255/255, g=255/255, b=000/255} -- yellow
	},
	mk4 = {
		tint = {r=000/255, g=128/255, b=000/255} -- dark green
	},
	mk5 = {
		tint = {r=255/255, g=128/255, b=000/255} -- orange
	},
	mk6 = {
		tint = {r=128/255, g=064/255, b=000/255} -- brown
	},
	mk7 = {
		tint = {r=128/255, g=000/255, b=000/255} -- dark red
	},
	mk8 = {
		tint = {r=064/255, g=000/255, b=000/255} -- very dark red
	}
}