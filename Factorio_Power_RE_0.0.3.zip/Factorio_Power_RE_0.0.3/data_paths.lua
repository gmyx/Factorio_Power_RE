
--Generates all the paths for this mod. This makes it possible to easily change the name whenever it is necessary.
modname="__Factorio_Power_RE__"
iconpath=modname.."/graphics/icons/"
entitypath=modname.."/graphics/entity/"
