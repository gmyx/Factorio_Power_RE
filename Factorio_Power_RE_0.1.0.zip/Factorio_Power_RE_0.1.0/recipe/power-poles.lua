data:extend({

  {
      type = "recipe",
      name = "big-wooden-pole",
      ingredients =
      {
        {"wood", 5},
        {"copper-cable", 10}
      },
      result = "big-wooden-pole",
      enabled = "true"
  }
})